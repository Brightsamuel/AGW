import React, { useEffect, useState } from "react";
import { ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const images = [
  "/images/img7.jpeg",
  "/images/ii1.jpg",
  "/images/ii2.jpg",
  // Add more image paths as needed
];

const IndustrialInstallationsPage = () => {
  const [bgIndex, setBgIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsTransitioning(true);
      setTimeout(() => {
        setBgIndex((prev) => (prev + 1) % images.length);
        setIsTransitioning(false);
      }, 500); // Half the transition time for smooth overlap
    }, 5000); // Shuffle every 5 seconds
    return () => clearInterval(interval);
  }, []);

  // Preload images to prevent loading delays
  useEffect(() => {
    images.forEach((image) => {
      const img = new Image();
      img.src = image;
    });
  }, []);

  return (
    <div className="min-h-screen pt-20 bg-gray-50">
      {/* Hero Section with Shuffling Background */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          {images.map((image, index) => {
            const isCurrent = index === bgIndex;
            const isNext = index === (bgIndex + 1) % images.length && isTransitioning;
            const isPrevious = index === (bgIndex - 1 + images.length) % images.length && isTransitioning;

            return (
              <div
                key={index}
                className={`
                  absolute inset-0 transition-all duration-1000 ease-in-out transform
                  ${isCurrent ? 'opacity-100 scale-100 translate-x-0' : ''}
                  ${isNext ? 'opacity-50 scale-105 translate-x-full' : ''}
                  ${isPrevious ? 'opacity-50 scale-105 -translate-x-full' : ''}
                  ${!isCurrent && !isNext && !isPrevious ? 'opacity-0 scale-90 translate-x-0' : ''}
                `}
                style={{
                  backgroundImage: `url(${image})`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center',
                  zIndex: isCurrent ? 2 : isNext || isPrevious ? 1 : 0,
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-black/30 to-black/50"></div>
              </div>
            );
          })}
        </div>

        <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto animate-fade-in">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 drop-shadow-lg">Industrial Installations</h1>
          <p className="text-lg md:text-xl opacity-90 mb-6 leading-relaxed drop-shadow-md">
            Precision engineering for air conditioning, piping, and power systems.
          </p>
          <p className="text-base opacity-80 max-w-2xl mx-auto drop-shadow-sm">
            Expert installations tailored to enhance efficiency and reliability in industrial environments.
          </p>
        </div>
      </section>

      {/* Main Content Section - Building on Original Design */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="bg-white rounded-lg shadow-lg p-8 max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Our Industrial Installation Services</h2>
            <p className="mb-8 text-gray-700 text-center leading-relaxed">
              Admirals Group specializes in professional industrial installations, delivering seamless solutions for HVAC, piping, and electrical systems to optimize your operations and ensure long-term performance.
            </p>
            
            <div className="space-y-8">
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg">
                <h3 className="text-2xl font-semibold text-gray-800 mb-4 flex items-center">
                  Air Conditioning Systems
                </h3>
                <ul className="space-y-3 text-gray-700 pl-6 list-disc">
                  <li className="text-sm leading-relaxed">
                    Comprehensive design, installation, and maintenance of HVAC systems for industrial facilities.
                  </li>
                  <li className="text-sm leading-relaxed">
                    Energy-efficient solutions tailored to specific environmental and operational requirements.
                  </li>
                </ul>
              </div>

              <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-lg">
                <h3 className="text-2xl font-semibold text-gray-800 mb-4 flex items-center">
                  Piping Installations
                </h3>
                <ul className="space-y-3 text-gray-700 pl-6 list-disc">
                  <li className="text-sm leading-relaxed">
                    Stainless steel, mild steel, and carbon steel piping for fluid transport and process systems.
                  </li>
                  <li className="text-sm leading-relaxed">
                    Precision fabrication and welding to meet industry standards and safety regulations.
                  </li>
                </ul>
              </div>

              <div className="bg-gradient-to-r from-orange-50 to-amber-50 p-6 rounded-lg">
                <h3 className="text-2xl font-semibold text-gray-800 mb-4 flex items-center">
                  Power Factor Improvement Equipment
                </h3>
                <ul className="space-y-3 text-gray-700 pl-6 list-disc">
                  <li className="text-sm leading-relaxed">
                    Installation of capacitor banks to optimize electrical efficiency and reduce energy costs.
                  </li>
                  <li className="text-sm leading-relaxed">
                    Customized solutions for industrial power systems to enhance performance and compliance.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section - Simple and Distinct */}
      <section className="bg-gray-800 text-white py-16 px-4 text-center">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold mb-4">Power Up Your Operations</h2>
          <p className="text-lg opacity-80 mb-8 leading-relaxed">
            Contact us to discuss your industrial installation needs and get a customized proposal.
          </p>
          <Link 
            to="/contact" 
            className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-full font-semibold text-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
          >
            Request Installation <ChevronRight className="w-5 h-5 ml-2 inline" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default IndustrialInstallationsPage;